"""
Authentication Module
Handles user login, logout and refresh token routes
"""

from typing import Annotated
from fastapi import (
    APIRouter,
    HTTPException,
    Depends,
    status,
    Request,
    BackgroundTasks,
    Query,
    Path,
    Body,
)

from fastapi.security import OAuth2PasswordRequestForm
import logging
from sqlalchemy.orm import Session
from db.database import get_db
from api.v1.schemas.user import (
    UserLogin,
    LoginResponseModel,
    SwaggerLoginToken,
    EmailStr,
    PasswordChangeRequest,
    PasswordResetRequest,
    ForgotPasswordRequest,
    MagicLinkToken,
    MagicLinkRequest,
)
from api.v1.schemas.auth import VerifyEmailOTPRequest
from api.v1.schemas.audit_logs import (
    AuditLogCreate,
    AuditLogEventEnum,
    AuditLogStatuses,
)
from api.v1.schemas.user import GeneralResponse, RefreshTokenRequest
from api.utils.json_response import JsonResponseDict
from api.utils.settings import settings
from api.utils.responses import auth_response
from api.utils.user_device_agent import (
    get_device_info,
    get_client_ip,
    generate_device_fingerprint,
)
from api.v1.models.user import User
from api.v1.services import (
    user_service,
    audit_log_service,
    devices_service,
    notification_service,
    geoip_service,
    totp_service,
)
from datetime import datetime, timezone, timedelta


auth_router = APIRouter(tags=["Auth"])
logger = logging.getLogger(__name__)


@auth_router.post(
    "/login", response_model=LoginResponseModel, status_code=status.HTTP_200_OK
)
async def login(
    request: Request,
    data: UserLogin,
    bgt: BackgroundTasks,
    db: Session = Depends(get_db),
    _: None = Depends(geoip_service.blacklisted_country_dependency_check),
):
    """Logs client in

    **Client may be regular users, moderator of admin**\n
    This endpoint is used to log in users using their email and password.\n
    **Payload:**

        email
        password
    """

    try:
        user = user_service.authenticate_user(
            db=db, email=data.email, password=data.password
        )
    except HTTPException as exc:
        return JsonResponseDict(
            status="failed",
            message=exc.detail,
            status_code=exc.status_code,
        )

    # check user 2fa status
    if user.totp_device and user.totp_device.confirmed:
        temp_token = user_service.create_and_encrypt_temp_login_token(
            user_id=user.id, ip_address=get_client_ip(request)
        )
        user.login_initiated = True
        user.save(db=db)
        return JsonResponseDict(
            message="Login initiated, Please provide OTP and your temporary token to complete login",
            status_code=status.HTTP_202_ACCEPTED,
            status="pending",
            data={
                "requires_2fa": True,
                "temp_token": temp_token,
                "next_action_url": request.url_for("verify_sms_otp_code"),
            },
        )

    # save user device info
    device_info = await get_device_info(request)

    # check if device is familiar, else trigger email otp verification
    if not devices_service.is_device_familiar(
        db=db, user_id=user.id, device_info=device_info
    ):
        # if user has not logged in before, skip email verification
        if user.last_login is None:
            devices_service.create_with_bgt(
                db=db, owner=user, device_info=device_info, bgt=bgt
            )

        else:
            from api.utils.encrypters_and_decrypters import (
                generate_email_otp_login_temp_token,
            )

            # generate OTP code
            otp_code = totp_service.generate_email_otp_code(db=db, user_id=user.id)
            email_risk_based_auth_otp_temp_token = generate_email_otp_login_temp_token(
                user_id=user.id, validity=6
            )
            # send email verification for new device
            notification_service.send_email_otp_verification_code(
                user=user, otp_code=otp_code, bgt=bgt
            )
            return JsonResponseDict(
                message="New device detected, please verify your email to continue",
                status_code=status.HTTP_202_ACCEPTED,
                status="pending",
                data={
                    "requires_email_verification": True,
                    "next_action_url": request.url_for("verify_email_code"),
                    "temp_token": email_risk_based_auth_otp_temp_token,
                },
            )

    if device_info:
        devices_service.create_with_bgt(
            db=db, owner=user, device_info=device_info, bgt=bgt
        )

    try:
        # generate user tokens
        user_access_token = user_service.create_access_token(user_obj=user, db=db)
        user_refresh_token = user_service.create_refresh_token(
            db=db,
            user_id=user.id,
            user_device_fingerprint=generate_device_fingerprint(
                device_info.get("user_agent")
            ),
        )

    except HTTPException as exc:
        return JsonResponseDict(
            status="failed",
            message=exc.detail,
            status_code=exc.status_code,
        )

    user.email  # load object attrs

    response = auth_response(
        status="success",
        status_code=200,
        message="Login was successful",
        user_data=user.to_dict(),
        refresh_token=user_refresh_token,
        access_token=user_access_token,
    )

    # set cookies
    if settings.ALLOW_AUTH_COOKIES:
        JWT_REFRESH_EXPIRY_SECONDS = int(
            timedelta(days=settings.JWT_REFRESH_EXPIRY_DAYS).total_seconds()
        )
        response.set_cookie(
            key="refresh_token",
            value=user_refresh_token,
            httponly=True,
            secure=settings.AUTH_SECURE_COOKIES,
            samesite=settings.AUTH_COOKIE_SAME_SITE,
            path=request.url_for("refresh").path,
            expires=JWT_REFRESH_EXPIRY_SECONDS,
        )

    # audit log
    audit_log_service.log(
        db=db,
        background_task=bgt,
        schema=AuditLogCreate(
            user_id=user.id,
            event=AuditLogEventEnum.LOGIN,
            description="user logged in with password",
            status=AuditLogStatuses.SUCCESS,
            ip_address=device_info.get("ip_address"),
            user_agent=device_info.get("user_agent"),
        ),
    )

    return response


@auth_router.post(
    "/swagger-login", status_code=status.HTTP_200_OK, include_in_schema=False
)
async def login_in_openapi_swagger(
    form_data: Annotated[OAuth2PasswordRequestForm, Depends()],
    db: Session = Depends(get_db),
):
    """
    Provides authentication for swagger UI Documentation testing
    """
    user = user_service.authenticate_user(
        db=db, email=form_data.username, password=form_data.password
    )
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if user_service.perform_user_check(user=user):
        access_token = user_service.create_access_token(user_obj=user, db=db)

    return SwaggerLoginToken(access_token=access_token, token_type="bearer")


@auth_router.post(
    "/magic-link/request",
    response_model=GeneralResponse,
    status_code=status.HTTP_200_OK,
)
async def request_magic_link_login(
    request: Request,
    bgt: BackgroundTasks,
    email: MagicLinkRequest,
    db: Session = Depends(get_db),
    _: None = Depends(geoip_service.blacklisted_country_dependency_check),
):
    """Send magic link to user"""

    user = user_service.fetch(db, email.email)
    user_service.perform_user_check(user=user)

    # send magic link mail to user
    notification_service.send_magic_link_mail(user=user, bgt=bgt)

    # loging the event in audit logs
    device_info = await get_device_info(request)
    audit_log_service.log(
        db=db,
        schema=AuditLogCreate(
            user_id=user.id,
            event=AuditLogEventEnum.REQUEST_MAGIC_LINK,
            description="User requested magic link",
            status=AuditLogStatuses.SUCCESS,
            ip_address=device_info.get("ip_address"),
            user_agent=device_info.get("user_agent"),
        ),
        background_task=bgt,
    )

    return JsonResponseDict(
        message="Magic link has been sent to your email",
        status_code=status.HTTP_200_OK,
    )


@auth_router.post(
    "/magic-link/verify",
    response_model=LoginResponseModel,
    status_code=status.HTTP_200_OK,
)
async def magic_link_login(
    schema: MagicLinkToken,
    bgt: BackgroundTasks,
    request: Request,
    db: Session = Depends(get_db),
    _: None = Depends(geoip_service.blacklisted_country_dependency_check),
):
    """verifies magic link token and logs user in"""

    user = user_service.authenticate_user_with_magic_link(db, schema.token)
    # save user device info (if new device)
    device_info = await get_device_info(request)
    if device_info:
        devices_service.create_with_bgt(
            db=db, owner=user, device_info=device_info, bgt=bgt
        )

    # generate user tokens
    user_access_token = user_service.create_access_token(user_obj=user, db=db)
    user_refresh_token = user_service.create_refresh_token(
        db=db,
        user_id=user.id,
        user_device_fingerprint=generate_device_fingerprint(
            device_info.get("user_agent")
        ),
    )

    user.email  # load the user object attributes.

    response = auth_response(
        status="success",
        status_code=200,
        message="Login successful",
        user_data=user.to_dict(),
        refresh_token=user_refresh_token,
        access_token=user_access_token,
    )

    if settings.ALLOW_AUTH_COOKIES:
        JWT_REFRESH_EXPIRY_SECONDS = int(
            timedelta(days=settings.JWT_REFRESH_EXPIRY_DAYS).total_seconds()
        )
        response.set_cookie(
            key="refresh_token",
            value=user_refresh_token,
            httponly=True,
            secure=settings.AUTH_SECURE_COOKIES,
            samesite=settings.AUTH_COOKIE_SAME_SITE,
            path=request.url_for("refresh").path,
            expires=JWT_REFRESH_EXPIRY_SECONDS,  # set to days equivalent in seconds
        )

        # loging the event in audit logs
        audit_log_service.log(
            db=db,
            schema=AuditLogCreate(
                user_id=user.id,
                event=AuditLogEventEnum.LOGIN,
                description="User logged in using magic link",
                status=AuditLogStatuses.SUCCESS,
                ip_address=device_info.get("ip_address", "N/A"),
                user_agent=device_info.get("user_agent", "N/A"),
            ),
            background_task=bgt,
        )

    return response


@auth_router.post("/logout", status_code=status.HTTP_200_OK)
async def logout(
    refresh_token_schema: RefreshTokenRequest,
    request: Request,
    db: Session = Depends(get_db),
):
    """Logs user out of the system"""

    refresh_token = refresh_token_schema.refresh_token or request.cookies.get(
        settings.REFRESH_TOKEN_COOKIE_NAME
    )
    if refresh_token:
        try:
            user_service.revoke_refresh_token(db=db, token=refresh_token)
        except HTTPException as exc:
            return JsonResponseDict(
                message=exc.detail,
                status="failed",
                status_code=exc.status_code,
            )

        response = JsonResponseDict(
            message="Logout was successful",
            status="success",
            status_code=status.HTTP_200_OK,
        )
        if settings.ALLOW_AUTH_COOKIES:
            response.delete_cookie(key="access_token")
            response.delete_cookie(key="refresh_token")

        return response
    else:
        return JsonResponseDict(
            message="Refresh token is required",
            status_code=status.HTTP_400_BAD_REQUEST,
        )


@auth_router.post("/refresh", status_code=status.HTTP_200_OK)
async def refresh(
    refresh_token_schema: RefreshTokenRequest,
    bgt: BackgroundTasks,
    request: Request,
    db: Session = Depends(get_db),
    _: None = Depends(geoip_service.blacklisted_country_dependency_check),
):
    """Refreshes user token"""

    refresh_token = refresh_token_schema.refresh_token or request.cookies.get(
        settings.REFRESH_TOKEN_COOKIE_NAME
    )
    if not refresh_token:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Refresh token is required (either in request body or cookies)",
        )

    device_info = await get_device_info(request)

    curr_device_fprt = generate_device_fingerprint(device_info.get("user_agent"))

    new_access_token, new_refresh_token, user = user_service.refresh_access_token(
        db,
        refresh_token,
        current_device_fingerprint=curr_device_fprt,
    )

    response = JsonResponseDict(
        message="Token refreshed",
        status="success",
        status_code=status.HTTP_200_OK,
        data={
            "access": new_access_token,
            "refresh": new_refresh_token,
        },
    )

    # loging the event in audit logs
    audit_log_service.log(
        db=db,
        background_task=bgt,
        schema=AuditLogCreate(
            user_id=user.id,
            event=AuditLogEventEnum.LOGIN,
            description="user refreshed their auth tokens",
            status=AuditLogStatuses.SUCCESS,
            ip_address=device_info.get("ip_address"),
            user_agent=device_info.get("user_agent"),
        ),
    )

    # perform other logic such as setting cookies
    if settings.ALLOW_AUTH_COOKIES:
        JWT_REFRESH_EXPIRY_SECONDS = int(
            timedelta(days=settings.JWT_REFRESH_EXPIRY_DAYS).total_seconds()
        )
        response.set_cookie(
            key="refresh_token",
            value=new_refresh_token,
            httponly=True,
            secure=settings.AUTH_SECURE_COOKIES,
            samesite=settings.AUTH_COOKIE_SAME_SITE,
            path="/auth/api/v1/",
            expires=JWT_REFRESH_EXPIRY_SECONDS,
        )

    return response


# PASSWORD RELATED ENDPOINTS
@auth_router.post(
    "/forgot-password",
    summary="Endpoint to request password reset",
    status_code=status.HTTP_200_OK,
)
async def forgot_password(
    data: ForgotPasswordRequest,
    bgt: BackgroundTasks,
    db: Session = Depends(get_db),
):
    """Request password reset"""

    user = user_service.fetch(db=db, email=data.email)

    if user:
        notification_service.send_password_reset_mail(user=user, bgt=bgt)

    return JsonResponseDict(
        message="If that email address exists in our system, you will receive a password reset link shortly.",
        status_code=200,
    )


@auth_router.post(
    "/reset-password",
    summary="Endpoint to reset user password",
    status_code=status.HTTP_200_OK,
)
async def reset_password(
    request: Request,
    bgt: BackgroundTasks,
    token: str = Query(..., description="Password reset token"),
    data: PasswordResetRequest = Body(..., description="New Password"),
    db: Session = Depends(get_db),
    _: None = Depends(geoip_service.blacklisted_country_dependency_check),
):
    """Reset user password"""

    from api.utils.encrypters_and_decrypters import decrypt_password_reset_token

    # decrypt token
    user_email = decrypt_password_reset_token(token)
    # token is authentic, validate if it's been previously used.
    user_service.validate_temp_token_and_mark_as_used(db=db, token=token)

    # check if user exists
    user = user_service.fetch(db=db, email=user_email)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Auth user does not exist"
        )

    # Check user status
    user_service.perform_user_check(user=user)

    device_info = await get_device_info(request)

    # change(reset) user password
    access_token, refresh_token = user_service.change_password(
        new_password=data.new_password,
        user=user,
        db=db,
        mode="reset",
        current_device_fingerprint=generate_device_fingerprint(
            device_info.get("user_agent")
        ),
    )

    # send notification to user
    notification_service.send_success_password_reset_or_changed_mail(user=user, bgt=bgt)

    # loging the event in audit logs
    audit_log_service.log(
        db=db,
        background_task=bgt,
        schema=AuditLogCreate(
            user_id=user.id,
            event=AuditLogEventEnum.RESET_PASSWORD,
            description="User reset their account password",
            status=AuditLogStatuses.SUCCESS,
            ip_address=device_info.get("ip_address", "N/A"),
            user_agent=device_info.get("user_agent", "N/A"),
        ),
    )

    return JsonResponseDict(
        message="Password reset successful",
        status_code=status.HTTP_200_OK,
        data={
            "access": access_token,
            "refresh": refresh_token,
        },
    )


@auth_router.post(
    "/change-password",
    summary="Endpoint to change user password",
    status_code=status.HTTP_200_OK,
)
async def change_password(
    data: PasswordChangeRequest,
    bgt: BackgroundTasks,
    request: Request,
    user: User = Depends(user_service.get_current_user),
    db: Session = Depends(get_db),
):
    """Change user password"""

    # Check if user is authenticated
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not authenticated",
        )

    device_info = await get_device_info(request)
    dft = generate_device_fingerprint(device_info.get("user_agent"))

    # change user password
    access_token, refresh_token = user_service.change_password(
        new_password=data.new_password,
        old_password=data.old_password,
        user=user,
        db=db,
        current_device_fingerprint=dft,
    )

    # send notification to user
    notification_service.send_success_password_reset_or_changed_mail(user=user, bgt=bgt)

    # loging the event in audit logs
    audit_log_service.log(
        db=db,
        background_task=bgt,
        schema=AuditLogCreate(
            user_id=user.id,
            event=AuditLogEventEnum.CHANGED_PASSWORD,
            description="User changed their account password",
            status=AuditLogStatuses.SUCCESS,
            ip_address=device_info.get("ip_address", "N/A"),
            user_agent=device_info.get("user_agent", "N/A"),
        ),
    )

    return JsonResponseDict(
        message="Password changed successfully",
        status_code=status.HTTP_200_OK,
        data={
            "access": access_token,
            "refresh": refresh_token,
        },
    )


# EMAIL VERIFICATION ENDPOINTS


@auth_router.post(
    "/verify-email",
    summary="Endpoint to verify user email.",
    status_code=status.HTTP_200_OK,
)
async def verify_email(
    bgt: BackgroundTasks,
    request: Request,
    token: str = Query(..., description="verification token"),
    db: Session = Depends(get_db),
):
    """Verifies user email/account"""
    from api.utils.encrypters_and_decrypters import decrypt_verification_token

    user_email = decrypt_verification_token(token)
    # token was successfully verified and decrypted (authentic), check token use status
    user_service.validate_temp_token_and_mark_as_used(db=db, token=token)

    user = user_service.fetch(db=db, email=user_email)

    # Check if user is already verified
    if user.is_verified:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT, detail="Email is already verified."
        )

    # verify and activate user
    user.is_verified = True
    user.is_active = True
    user.save(db=db)

    # send notification to user
    notification_service.send_welcome_mail(user=user, bgt=bgt)

    # loging the event in audit logs
    device_info = await get_device_info(request)
    log_description = "User email verified"
    try:
        schema = AuditLogCreate(
            user_id=user.id,
            event=AuditLogEventEnum.VERIFY_EMAIL,
            description=log_description,
            ip_address=device_info.get("ip_address", "N/A"),
            user_agent=device_info.get("user_agent", "N/A"),
            status=AuditLogStatuses.SUCCESS,
        )
        audit_log_service.log(db=db, schema=schema, background_task=bgt)

        # log to logger
        logger.info(f"Audit Log ({user.email}) email verified")
    except Exception as exc:
        logger.info(
            f"Failed to Audit Log ({user.email}) email verification, error {exc}"
        )

    return JsonResponseDict(
        message="Email verified",
        status_code=200,
    )


@auth_router.post(
    "/resend-verification-email",
    summary="Endpoint to resend email verification",
    status_code=status.HTTP_200_OK,
)
async def resend_verification(
    request: Request,
    bgt: BackgroundTasks,
    email: EmailStr = Query(..., description="User Email"),
    db: Session = Depends(get_db),
):
    """Request for new user email verification"""

    # perform logic to resend email verification
    user = user_service.fetch(db=db, email=email)

    # Check if user is already verified
    if user.is_verified:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT, detail="Email is already verified."
        )

    # send verification mail to user
    notification_service.send_verify_email_mail(user=user, bgt=bgt)

    # capture user device
    device_info = await get_device_info(request)

    # loging the event in audit logs
    log_description = "User requested resend of email verification link"
    try:
        schema = AuditLogCreate(
            user_id=user.id,
            event=AuditLogEventEnum.REQUEST_VERIFICATION,
            description=log_description,
            ip_address=device_info.get("ip_address", "N/A"),
            user_agent=device_info.get("user_agent", "N/A"),
            status=AuditLogStatuses.SUCCESS,
        )
        audit_log_service.log(db=db, schema=schema, background_task=bgt)

        # log to logger
        logger.info(f"Audit Log ({user.email}) request for verification email")

    except Exception as exc:
        logger.info(
            f"Failed to Audit Log ({user.email}) request for verification email, error {exc}"
        )

    return JsonResponseDict(
        message=f"verifcation email has been sent to {user.email}",
        status_code=200,
    )


@auth_router.post(
    "/verify-email-code",
    summary="Validate login email verification code",
    status_code=status.HTTP_200_OK,
)
async def verify_email_code(
    request: Request,
    req_data: VerifyEmailOTPRequest,
    bgt: BackgroundTasks,
    db: Session = Depends(get_db),
    geoip_info=Depends(geoip_service.blacklisted_country_dependency_check),
):
    """
    Verify OTP code received by email for risk-based/adaptive authentication
    """
    from api.utils.encrypters_and_decrypters import decrypt_email_otp_login_temp_token

    # Decrypt the temporary token
    user_id = decrypt_email_otp_login_temp_token(req_data.temp_token)
    # token is authentic, verify it is only used once
    user_service.validate_temp_token_and_mark_as_used(db=db, token=req_data.temp_token)

    # Verify the OTP code
    is_valid_code = totp_service.verify_email_otp_code(
        db=db, code=str(req_data.otp), user_identifier=user_id
    )

    if not is_valid_code:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid OTP code"
        )

    # Now that the OTP is valid, proceed with login
    user = user_service.fetch_by_id(db=db, id=user_id)

    # get device info
    device_info = await get_device_info(request)

    access_token = user_service.create_access_token(user_obj=user, db=db)
    user_refresh_token = user_service.create_refresh_token(
        db=db,
        user_id=user.id,
        user_device_fingerprint=generate_device_fingerprint(
            device_info.get("user_agent")
        ),
    )

    # notify user of new device if device is not familiar
    if not devices_service.is_device_familiar(
        db=db, user_id=user.id, device_info=device_info
    ):
        login_time = datetime.now(tz=timezone.utc)
        login_device_name = device_info.get("device_name", "N/A")
        login_ip_address = device_info.get("ip_address", "N/A")
        login_location = f"{geoip_info.city}, {geoip_info.country_name}" or "Unknown"
        notification_service.send_new_device_login_alert(
            user=user,
            login_time=login_time,
            login_location=login_location,
            login_device_name=login_device_name,
            login_ip_address=login_ip_address,
            bgt=bgt,
        )

    # add the new device to user account
    # user can remove or report new device if they didn't add it
    # since alert is sent to their email
    devices_service.create_with_bgt(db=db, owner=user, device_info=device_info, bgt=bgt)

    response = auth_response(
        status="success",
        status_code=200,
        message="Login was successful",
        user_data=user.to_dict(),
        refresh_token=user_refresh_token,
        access_token=access_token,
    )

    # set cookies
    if settings.ALLOW_AUTH_COOKIES:
        JWT_REFRESH_EXPIRY_SECONDS = int(
            timedelta(days=settings.JWT_REFRESH_EXPIRY_DAYS).total_seconds()
        )
        response.set_cookie(
            key="refresh_token",
            value=user_refresh_token,
            httponly=True,
            secure=settings.AUTH_SECURE_COOKIES,
            samesite=settings.AUTH_COOKIE_SAME_SITE,
            path=request.url_for("refresh").path,
            expires=JWT_REFRESH_EXPIRY_SECONDS,
        )

    # audit log
    audit_log_service.log(
        db=db,
        background_task=bgt,
        schema=AuditLogCreate(
            user_id=user.id,
            event=AuditLogEventEnum.LOGIN,
            description="user logged in with password and email OTP for risk-based auth.",
            status=AuditLogStatuses.SUCCESS,
            ip_address=device_info.get("ip_address", "N/A"),
            user_agent=device_info.get("user_agent", "N/A"),
        ),
    )

    return response
