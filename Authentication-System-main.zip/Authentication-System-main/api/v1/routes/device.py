from fastapi import APIRouter, HTTPException, status, Depends, Path
from api.v1.models.user import User
from api.v1.services import user_service, devices_service
from api.utils.json_response import JsonResponseDict
from db.database import get_db
from sqlalchemy.orm import Session


user_device_router = APIRouter(prefix="/devices", tags=["User Device"])


@user_device_router.get("/@me", status_code=status.HTTP_200_OK)
def get_devices(user: User = Depends(user_service.get_current_user)):
    """
    Retrieve self devices information
    """

    user_devices = user.devices

    devices = [device.to_dict(hide_sensitive_info=True) for device in user_devices]
    return devices


@user_device_router.delete("/@me/{device_id}")
async def delete_self_device(
    device_id: str = Path(..., description="ID of the user's device to delete"),
    user: User = Depends(user_service.get_current_user),
    db: Session = Depends(get_db),
):
    """Delete a self device"""

    try:
        devices_service.delete(db=db, device_id=device_id)
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="We couldn't remove the device, try again later.",
        )

    return JsonResponseDict(
        message="Device removed successfully", status_code=status.HTTP_200_OK
    )


@user_device_router.get(
    "/user/{user_id}",
    tags=["Moderator", "Superadmin"],
    response_model=list,
    status_code=status.HTTP_200_OK,
)
def get_user_devices_by_user_id(
    user_id: str = Path(..., description="ID of the owner of the device"),
    admin: User = Depends(user_service.get_current_user),
    db: Session = Depends(get_db),
):
    """Get all devices belonging to a user"""

    user_service.ensure_administrator(admin)

    user_devices = user_service.fetch_by_id(db=db, id=user_id).devices
    user_devices = [
        device.to_dict(hide_sensitive_info=False) for device in user_devices
    ]

    return user_devices
