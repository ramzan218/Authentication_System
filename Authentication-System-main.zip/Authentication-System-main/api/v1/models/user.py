from sqlalchemy import Column, Boolean, String, Index, Enum, DateTime, LargeBinary
from sqlalchemy.orm import relationship
from api.v1.models.base_model import BaseModel
from api.v1.models.roles import auth_user_roles_association
from api.v1.schemas.user import LoginSource
from sqlalchemy.orm import Session
from pydantic import EmailStr
from typing import Tuple


class User(BaseModel):
    __tablename__ = "auth_users"

    email = Column(String(128), unique=True, nullable=False)
    recovery_email = Column(String(128), nullable=True)
    password = Column(String(256), nullable=False)
    is_active = Column(Boolean, default=False, nullable=False)
    is_verified = Column(Boolean, default=False, nullable=False)
    is_deleted = Column(Boolean, default=False, nullable=False)
    is_superadmin = Column(Boolean, default=False, nullable=False)
    is_moderator = Column(Boolean, default=False, nullable=False)
    login_initiated = Column(Boolean, default=False, nullable=False)
    last_login = Column(DateTime, nullable=True)
    login_source = Column(Enum(LoginSource), nullable=True)
    is_banned = Column(Boolean, default=False, nullable=False)

    secondary_roles = relationship(
        "SecondaryRole",
        backref="user",
        secondary=auth_user_roles_association,
        uselist=True,
    )
    attributes = relationship(
        "UserAttribute",
        backref="user",
        uselist=True,
        cascade="all, delete-orphan",
        # I'm using 'selectin' to reduce the number of queries when loading user with attributes
        lazy="selectin",
    )

    refresh_tokens = relationship(
        "RefreshToken",
        back_populates="user",
        uselist=True,
        cascade="all, delete-orphan",
    )
    devices = relationship(
        "Device", backref="user", uselist=True, cascade="all, delete-orphan"
    )
    totp_device = relationship(
        "TOTPDevice", backref="user", uselist=False, cascade="all, delete-orphan"
    )
    ban_history = relationship(
        "AccountBanHistory", backref="user", uselist=True, cascade="all, delete-orphan"
    )

    __table_args__ = (
        Index("ix_user_email", "email"),
        Index("ix_user_recovery_email", "recovery_email"),
        Index("ix_user_is_active", "is_active"),
        Index("ix_user_is_verified", "is_verified"),
        Index("ix_user_is_deleted", "is_deleted"),
        Index("ix_user_login_initiated", "login_initiated"),
        Index("ix_user_last_login", "last_login"),
        Index("ix_user_login_source", "login_source"),
        Index("ix_user_is_banned", "is_banned"),
        Index("ix_user_is_superadmin", "is_superadmin"),
        Index("ix_user_is_moderator", "is_moderator"),
    )

    def to_dict(self, hide_sensitive_data: bool = True):
        obj_dict = super().to_dict()
        # remove password
        obj_dict.pop("password", None)

        if hide_sensitive_data:
            obj_dict.pop("login_initiated", None)
            obj_dict.pop("is_deleted", None)
            obj_dict.pop("is_banned", None)

        # 1. Add secondary roles
        obj_dict["secondary_roles"] = []
        if self.secondary_roles:
            obj_dict["secondary_roles"] = [role.name for role in self.secondary_roles]

        # 2. Add attributes
        if self.attributes:
            attributes_dict = {}
            for user_attr_record in self.attributes:
                if user_attr_record.attribute and user_attr_record.attribute_value:
                    attribute_name = user_attr_record.attribute.name
                    attribute_value = user_attr_record.attribute_value.value
                    attributes_dict[attribute_name] = attribute_value
            obj_dict["attributes"] = attributes_dict

        return obj_dict

    def __str__(self):
        return self.email

    def __repr__(self):
        return f"<User(id={self.id}, email={self.email}, role={self.role})>"

    def save(self, db: Session):
        """save changes made to user object to database"""

        db.add(self)
        db.commit()
        db.refresh(self)

    def user_exists(
        self, db: Session, id: str = None, email: EmailStr = None
    ) -> Tuple[bool, "User"]:
        """
        Check if user exists in the database with the given email or ID.
        If both are given, it will check for the first one that is found.

        :param db: Database session
        :param email: User email
        :param id: User ID

        :return: (True, user_object) if user exists, (False, None) otherwise
        """

        if not any([email, id]):
            raise ValueError("At least email or id must be provided.")

        # initialize user to None
        user = None

        if id:
            # user = db.get(User, ident=id)
            user = db.query(User).filter_by(id=id).first()

        elif email:
            user = db.query(User).filter_by(email=email).first()

        if user:
            return (True, user)

        return False, None
