from fastapi import HTTPException, Depends, status, Security, Header
from starlette.requests import Request
from fastapi.security import OAuth2PasswordBearer
from passlib.context import CryptContext
from typing import Tuple, Optional, List
from pydantic import EmailStr
from sqlalchemy.orm import Session
import datetime as dt
from jose import JWTError, jwt, ExpiredSignatureError
from sqlalchemy import func
from db.database import get_db

from api.utils.settings import settings
from api.v1.models.user import User
from api.v1.models.refresh_token import RefreshToken
from api.v1.models.attributes import UserAttribute
from api.v1.models.account_ban_history import AccountBanHistory
from api.v1.models.temp_tokens import TempToken
from api.v1.schemas.audit_logs import (
    AuditLogCreate,
    AuditLogEventEnum,
    AuditLogStatuses,
)
from api.v1.schemas.user import (
    UserCreate,
    AccessTokenData,
    DeactivateUserSchema,
    UserUpdateSchema,
    LoginSource,
    BanHistoryStatusEnum,
)
from api.v1.schemas.roles import PrimaryRoleEnum
from api.core.base.services import Service
from api.utils.encrypters_and_decrypters import base64, cipher_suite
import logging


if settings.DEBUG_MODE:
    oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/api/v1/swagger-login")
else:
    oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/api/v1/login")

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
logger = logging.getLogger(__name__)


class UserService(Service):
    """Auth user service"""

    def __init__(self):
        """Initializes the user service class"""

        self.dft_string = "OAuth"  # default device fingerprint string

    def create(self, db: Session, schema: UserCreate):
        """Creates a Auth new user"""

        if db.query(User).filter(User.email == schema.email).first():
            raise HTTPException(
                status_code=409,
                detail="User with this email already exists",
            )

        # Hash password
        schema.password = self.hash_password(password=schema.password)

        # Create auth user object with hashed password and other attributes from schema
        try:
            user = User(**schema.model_dump())
            db.add(user)
            db.commit()
            db.refresh(user)
        except Exception as exc:
            # log error
            print(exc)
            raise HTTPException(status_code=500, detail="There was a database error")

        return user

    def fetch(self, db: Session, email: EmailStr):
        """fetch a single user from the system"""

        user = db.query(User).filter(User.email == email).first()
        if not user:
            raise HTTPException(
                status_code=404, detail="Auth user does not exist in our system!"
            )
        return user

    def fetch_by_id(self, db: Session, id: str) -> User:
        """fetch a single user from the system"""

        # user = db.query(User).filter(User.id == id).first()
        user = db.get(entity=User, ident=id)
        if not user:
            raise HTTPException(
                status_code=404, detail="Auth user does not exist in our system!"
            )

        return user

    def fetch_all(self, db: Session):
        """fetch all auth user in the system"""

        all_users = db.query(User).all()
        return all_users

    def fetch_all_paginated(self, db: Session, page: int = 1, per_page: int = 10):
        """
        Fetch all auth user in the system with no respect for
        statuses [active status, deletion status, and verification status]

        Args:
            :param page: int: page number
            :param per_page: int: number of items per page

        Returns:
            :return: Tuple[User, int]: Tuple of users and total number of users
        """

        # Calculate the offset for pagination
        offset = (page - 1) * per_page

        # Query to get paginated users
        users = db.query(User).offset(offset).limit(per_page).all()

        # Query to get the total number of users
        total = db.query(func.count(User.id)).scalar()

        return users, total

    def fetch_all_paginated_with_filters(
        self,
        db: Session,
        page: int,
        per_page: int,
        is_active: bool = True,
        is_deleted: bool = False,
        is_verified: bool = True,
    ) -> Tuple[List[User], int]:
        """
        Fetch all auth users in the system with optional filters.

        Args:
            :param page: int: page number
            :param per_page: int: number of items per page
            :param is_active: bool: Filter users based on active status
            :param is_deleted: bool: Filter users based on deletion status
            :param is_verified: bool: Filter users based on verification status

        Returns:
            :return: Tuple[List[User], int]: Tuple of users and total number of users matching filters
        """
        # Calculate the offset for pagination
        offset = (page - 1) * per_page

        # Make query
        users = (
            db.query(User)
            .filter(
                *(
                    User.is_active == is_active,
                    User.is_deleted == is_deleted,
                    User.is_verified == is_verified,
                )
            )
            .offset(offset)
            .limit(per_page)
            .all()
        )

        # Get the total number of filtered users
        total = (
            db.query(func.count(User.id))
            .filter(
                *(
                    User.is_active == is_active,
                    User.is_deleted == is_deleted,
                    User.is_verified == is_verified,
                )
            )
            .scalar()
        )

        return users, total

    def update(
        self,
        db: Session,
        schema: UserUpdateSchema,
        user_id: str = None,
        user_obj: User = None,
    ) -> User:
        """Update an Auth user data. must supply user_id or user_obj

        Args:
            db (Session): Database session.
            user_id (str): ID of the user to update.
            user_obj (User): User Object
            schema (UserUpdateSchema): Pydantic schema containing fields to update.

        Returns:
            User: The updated user object.
        """

        if not any([user_id, user_obj]):
            raise ValueError("User ID or User Object must be given")

        if user_obj:
            user = user_obj
        elif user_id:
            # Find the user by ID
            user = db.query(User).filter(User.id == user_id).first()
            if not user:
                raise HTTPException(status_code=404, detail="User not found")

        # Convert the schema to a dictionary (excluding unset fields)
        update_data = schema.model_dump(exclude_unset=True)

        # Update the user fields
        for key, value in update_data.items():
            if key == "recovery_email":
                if value == user.email:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="User email and recovery email cannot be the same.",
                    )

            if key == "email":
                if value == user.email:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Old and new email cannot be the same",
                    )
            setattr(user, key, value)

        db.commit()
        db.refresh(user)

        return user

    def delete(self, db: Session, user_id: str) -> User:
        """
        deletes an auth user from the system
        """

        user = self.fetch_by_id(db=db, id=user_id)

        if user.is_deleted is True:
            raise HTTPException(
                detail="Forbidden, User has been previously deleted!", status_code=403
            )

        try:
            setattr(user, "is_deleted", True)
            setattr(user, "is_active", False)
            self.deactivate_user
            db.commit()
            db.refresh(user)
        except Exception as exc:
            raise HTTPException(
                status_code=500, detail="Database operation to delete user failed"
            )

        return user

    def hard_delete_user(self, db: Session, user_id: str) -> User:
        """
        Remove user totally from the system.\n
        retains no user record
        """

        user = self.fetch_by_id(db=db, id=user_id)

        db.delete(user)
        db.commit()

        return user

    def authenticate_user(self, db: Session, email: str, password: str) -> User:
        """Function to authenticate a user with password"""

        user = db.query(User).filter(User.email == email).first()

        if not user:
            raise HTTPException(status_code=404, detail="User does not exist")

        self.perform_user_check(user)

        if not self.verify_password(password, user.password):
            raise HTTPException(status_code=400, detail="Invalid user credentials")

        user.last_login = dt.datetime.now(dt.timezone.utc)
        user.login_source = LoginSource.PASSWORD
        user.save(db)

        return user

    def authenticate_user_with_magic_link(self, db: Session, magic_token: str) -> User:
        """Function to authenticate a user with magic link"""

        from api.utils.encrypters_and_decrypters import decrypt_magic_link_token

        user_email = decrypt_magic_link_token(magic_token)
        self.validate_temp_token_and_mark_as_used(db=db, token=magic_token)
        user = db.query(User).filter(User.email == user_email).first()
        if not user:
            raise HTTPException(status_code=404, detail="User does not exist")

        self.perform_user_check(user)

        user.last_login = dt.datetime.now(dt.timezone.utc)
        user.login_source = LoginSource.MAGICLINK
        user.save(db=db)

        return user

    def perform_user_check(self, user: User) -> True:
        """
        This checks if a user is active and verified and not a deleted or banned user.\n
        It raises an HTTPException if any of the checks fail.\n
        This is important for security purposes and to ensure that the user
        is allowed to perform actions that require authentication.\n

        :param user: User: User object
        :return: bool: True if all checks pass
        :raises HTTPException: if any of the checks fail
        """

        if not user.is_verified:
            raise HTTPException(
                detail="User is not verified", status_code=status.HTTP_401_UNAUTHORIZED
            )
        if user.is_deleted:
            from api.v1.services import audit_log_service

            audit_log_service.log_without_bgt(
                schema=AuditLogCreate(
                    user_id=user.id,
                    event=AuditLogEventEnum.LOGIN,
                    description="Deleted user attempted login",
                    status=AuditLogStatuses.FAILED,
                    ip_address="Not Captured",
                    user_agent="Not Captured",
                )
            )
            raise HTTPException(
                detail="User does not exist",
                status_code=status.HTTP_401_UNAUTHORIZED,
            )

        if not user.is_active:
            raise HTTPException(
                detail="User is deactivated",
                status_code=status.HTTP_403_FORBIDDEN,
            )

        if user.is_banned:
            raise HTTPException(
                detail="User has banned from using this service",
                status_code=status.HTTP_403_FORBIDDEN,
            )

        if user.is_deleted:
            raise HTTPException(
                detail="The account has been deleted. Please contact support if this is a mistake.",
                status_code=status.HTTP_403_FORBIDDEN,
            )

        return True

    def hash_password(self, password: str) -> str:
        """Function to hash a password"""

        hashed_password = pwd_context.hash(secret=password)
        return hashed_password

    def verify_password(self, password: str, hash: str) -> bool:
        """Function to verify a hashed password"""

        return pwd_context.verify(secret=password, hash=hash)

    def create_access_token(self, db: Session, user_obj: User) -> str:
        """Function to create access token"""

        try:
            secondary_roles = [role.name for role in user_obj.secondary_roles]
            user_id = user_obj.id

            # define user role
            user_role = "user"
            if user_obj.is_superadmin:
                user_role = "superadmin"
            elif user_obj.is_moderator:
                user_role = "moderator"

            expires = dt.datetime.now(dt.timezone.utc) + dt.timedelta(
                minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
            )
            data = {
                "iss": settings.APP_URL or settings.APP_NAME or "Authentication System",
                "sub": user_id,
                "exp": expires,
                "type": "access",
                "primary_role": user_role,
                "secondary_roles": secondary_roles,
            }

            attributes = self.get_user_attributes(db=db, user_obj=user_obj)
            if attributes:
                data["attributes"] = attributes

            encoded_jwt = jwt.encode(data, settings.SECRET_KEY, settings.ALGORITHM)
        except Exception as exc:
            print(exc)
            raise HTTPException(
                status_code=500, detail="Failed to generate user access token"
            ) from exc
        return encoded_jwt

    def create_refresh_token(
        self,
        db: Session,
        user_id: str,
        user_device_fingerprint: Optional[str] = None,
        by_oauth: Optional[bool] = False,
    ) -> str:
        """
        Function to create refresh token.

        `user_device_fingerprint` is used to track the device initiating auth request, so ALWAYS set it.
        only optional for OAuth2 login, mandatory for password login.
        """

        expires = dt.datetime.now(dt.timezone.utc) + dt.timedelta(
            days=settings.JWT_REFRESH_EXPIRY_DAYS
        )
        data = {"sub": user_id, "exp": expires, "type": "refresh"}
        if user_device_fingerprint:
            masked_user_device_fingerprint = (
                f"{user_device_fingerprint[:4]}...{user_device_fingerprint[-4:]}"
            )
            data.update({"dft": masked_user_device_fingerprint})
        elif by_oauth:
            # since device fingerprint is not used for OAuth, we can indicate the token is generated by OAuth
            data.update({"dft": self.dft_string})

        else:
            raise ValueError(
                "Refresh token creation error: oauth or device fingerprint not specified"
            )

        encoded_jwt = jwt.encode(data, settings.SECRET_KEY, settings.ALGORITHM)

        try:
            refresh_token = RefreshToken(
                token=encoded_jwt, user_id=user_id, expires_at=expires
            )
            db.add(refresh_token)
            db.commit()
        except Exception as exc:
            raise HTTPException(
                status_code=500, detail="Failed to save refresh token"
            ) from exc

        return encoded_jwt

    def create_account_reactivation_link(self, user: User, validity: int = 3) -> str:
        """
        Generates an account reactivation link

        :param user: User object
        :param validity: token validity period (days)
        """

        data = {
            "u": user.id,
            "exp": dt.datetime.now(tz=dt.timezone.utc) + dt.timedelta(days=validity),
            "type": "activation",
        }
        token = jwt.encode(data, settings.SECRET_KEY, settings.ALGORITHM)

        link_append = f"/accounts/reactivate?token={token}"

        if not settings.FRONTEND_ACOUNT_REACTIVATION_URL == "0":
            reactivation_link = (
                f"{settings.FRONTEND_ACOUNT_REACTIVATION_URL.strip('/')}" + link_append
            )
        else:
            reactivation_link = f"{settings.FRONTEND_HOME_URL.strip('/')}" + link_append

        return reactivation_link, validity

    def _batch_delete_refresh_tokens(self, db: Session, user_id: str) -> None:
        """Function to delete all refresh tokens for a user"""

        try:
            db.query(RefreshToken).filter(RefreshToken.user_id == user_id).delete()
            db.commit()
        except Exception as exc:
            raise HTTPException(
                status_code=500, detail="Failed to delete refresh tokens"
            ) from exc
        return None

    def verify_access_token(self, access_token: str, credentials_exception):
        """Funtcion to decode and verify access token"""

        try:
            payload = jwt.decode(
                access_token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
            )
            user_id = payload.get("sub")
            token_type = payload.get("type")

            if user_id is None:
                raise credentials_exception

            if token_type == "refresh":
                raise HTTPException(detail="Refresh token not allowed", status_code=400)

            token_data = AccessTokenData(id=user_id)

        except JWTError as err:
            raise credentials_exception

        return token_data

    def verify_and_revoke_refresh_token(
        self, db: Session, refresh_token: str, credentials_exception
    ) -> AccessTokenData:
        """
        Funtcion to decode and verify refresh token.
        Also automatically revokes the token since refresh tokens are single use
        and should be rotated after use.
        """

        refresh_token_obj = None

        try:

            # Decode the refresh token
            payload = jwt.decode(
                refresh_token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
            )
            user_id = payload.get("sub")
            token_type = payload.get("type")
            dft = payload.get("dft")

            if user_id is None:
                raise credentials_exception

            if token_type == "access":
                raise HTTPException(detail="Access token not allowed", status_code=400)

            if dft != self.dft_string:
                if len(dft) == 64:
                    raise HTTPException(detail="Unrecognized dft", status_code=400)

            refresh_token_obj = (
                db.query(RefreshToken)
                .filter(
                    RefreshToken.user_id == user_id,
                    RefreshToken.token == refresh_token,
                )
                .first()
            )

            if not refresh_token_obj:
                raise HTTPException(status_code=400, detail="Untracked token")
            if refresh_token_obj.revoked:
                raise HTTPException(status_code=400, detail="Token has been revoked")

            token_data = AccessTokenData(id=user_id, dft=dft)

        except ExpiredSignatureError as exc:
            raise credentials_exception from exc

        except JWTError as exc:
            raise HTTPException(
                status_code=400, detail="Invalid token, please input a valid token"
            ) from exc

        except Exception as exc:

            if hasattr(exc, "detail"):
                raise HTTPException(
                    status_code=exc.status_code, detail=exc.detail
                ) from exc
            raise HTTPException(
                status_code=400, detail="Invalid token, please input a valid token"
            ) from exc

        finally:
            if refresh_token_obj:
                refresh_token_obj.revoked = True
                db.add(refresh_token_obj)
                db.commit()
                db.refresh(refresh_token_obj)

        return token_data

    def revoke_refresh_token(self, db: Session, token: str) -> None:
        """Function to revoke refresh token"""

        if not token:
            raise HTTPException(status_code=400, detail="No token provided")

        try:
            payload = jwt.decode(
                token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
            )
            owner_id = payload.get("sub")
            token_type = payload.get("type")

            if owner_id is None:
                raise HTTPException(400, "Invalid token")
            if token_type == "access" or token_type is None:
                raise HTTPException(400, "Invalid token")
        except ExpiredSignatureError:
            raise HTTPException(400, "Token expired")

        except JWTError as exc:
            raise HTTPException(400, "Invalid token") from exc

        refresh_token = (
            db.query(RefreshToken)
            .filter(
                RefreshToken.user_id == owner_id,
                RefreshToken.token == token,
            )
            .first()
        )

        if not refresh_token:
            raise HTTPException(400, "Invalid token")
        if refresh_token.revoked:
            raise HTTPException(400, "Token has been revoked")

        refresh_token.revoked = True
        db.add(refresh_token)
        db.commit()

    def refresh_access_token(
        self, db: Session, current_refresh_token: str, current_device_fingerprint: str
    ) -> Tuple[str, str]:
        """
        Function to generate new access token and rotate refresh token.
        Revokes current refresh token.

        Return (access_token, refresh_token, user)
        """

        credentials_exception = HTTPException(
            status_code=401, detail="Refresh token expired"
        )

        # Verify and revoke the refresh token
        # This will also check if the token is expired and raise an exception
        token = self.verify_and_revoke_refresh_token(
            db, current_refresh_token, credentials_exception
        )

        mismatch_exception = HTTPException(
            status_code=401,
            detail="Device fingerprint mismatch. Please login again.",
        )

        if token:

            # check the token owner status e.g. active, deleted, verified
            owner = self.fetch_by_id(db=db, id=token.id)
            # check user account status
            self.perform_user_check(user=owner)

            match_device = False
            user_devices = owner.devices
            for device in user_devices:
                if device.device_fingerprint == current_device_fingerprint:
                    match_device = True
                    break

            if not match_device:
                raise mismatch_exception

            to_match_dft = (
                f"{current_device_fingerprint[:4]}...{current_device_fingerprint[-4:]}"
            )

            if to_match_dft != token.dft:
                raise mismatch_exception

            access = self.create_access_token(db=db, user_obj=owner)
            refresh = self.create_refresh_token(
                db=db,
                user_id=token.id,
                user_device_fingerprint=current_device_fingerprint,
            )

            return (access, refresh, owner)

    def get_user_object_using_refresh_token(
        self, refresh_token: str, db: Session
    ) -> User | None:
        """decode and return token owner object"""

        credentials_exception = HTTPException(
            status_code=401,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

        try:

            # Decode the refresh token
            payload = jwt.decode(
                refresh_token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
            )
            user_id = payload.get("sub")
            token_type = payload.get("type")

            if user_id is None:
                raise credentials_exception

            if token_type != "refresh":
                raise credentials_exception

            owner = self.fetch_by_id(db=db, id=user_id)

        except ExpiredSignatureError:
            logger.critical(
                f"Detected jwt refresh token with unrecognized signature. Token: {refresh_token}",
                exc_info=1,
            )
            raise credentials_exception

        except Exception as exc:
            raise credentials_exception

        return owner

    def get_current_user(
        self,
        access_token: str = Security(oauth2_scheme),
        db: Session = Depends(get_db),
    ) -> User:
        """
        Dependency to get current logged in user.

        request will fail if user is deactivated or deleted
        """
        try:
            credentials_exception = HTTPException(
                status_code=401,
                detail="Could not validate credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )

            token = self.verify_access_token(access_token, credentials_exception)
            user = db.query(User).filter(User.id == token.id).first()
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND, detail="User does not exist"
                )

            # check user status, will raise error if user status is negative
            self.perform_user_check(user=user)
        except HTTPException as exc:
            raise exc
        return user

    def get_current_superadmin(
        self,
        access_token: str = Security(oauth2_scheme),
        db: Session = Depends(get_db),
    ):
        """Dependency to get current superadmin user"""
        try:
            credentials_exception = HTTPException(
                status_code=401,
                detail="Could not validate credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )

            token = self.verify_access_token(access_token, credentials_exception)
            user = db.query(User).filter(User.id == token.id).first()
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Auth user does not exist",
                )

            # check user status, will raise error if user status is negative
            self.perform_user_check(user=user)
            if not user.is_superadmin:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="You do not have permission to perform this action",
                )
        except HTTPException as exc:
            raise exc
        return user

    def get_current_moderator(
        self,
        access_token: str = Security(oauth2_scheme),
        db: Session = Depends(get_db),
    ):
        """Dependency to get current moderator user"""
        try:
            credentials_exception = HTTPException(
                status_code=401,
                detail="Could not validate credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )

            token = self.verify_access_token(access_token, credentials_exception)
            user = db.query(User).filter(User.id == token.id).first()
            if not user:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND, detail="User does not exist"
                )

            # check user status, will raise error if user status is negative
            self.perform_user_check(user=user)

            if not user.is_moderator:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Not enough permission.",
                )
        except HTTPException as exc:
            raise exc
        return user

    def deactivate_user(
        self,
        db: Session,
        schema: DeactivateUserSchema,
        user: User,
    ) -> str:
        """Function to deactivate a user. return a reactivation link"""

        if not schema.confirmation:
            raise HTTPException(
                detail="Confirmation required to deactivate account", status_code=400
            )

        self.perform_user_check(user)

        user.is_active = False

        # Create reactivation link
        reactivation_link, _ = self.create_account_reactivation_link(user=user)

        db.commit()

        return reactivation_link

    def reactivate_user(self, db: Session, email: str, token: str) -> User:
        """This function reactivates a user account"""

        # Validate the token
        try:
            payload = jwt.decode(
                token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
            )
            user_id = payload.get("u")

            if user_id is None:
                raise HTTPException(400, "Invalid token")
            if payload.get("type", None) != "activation":
                raise HTTPException(400, "Invalid token")

        except JWTError:
            raise HTTPException(400, "Invalid token")

        try:
            user = self.fetch_by_id(db=db, id=user_id)

            if user.is_active:
                raise HTTPException(409, "user is already active")

            if user.email != email:
                raise HTTPException(400, "token and email given are not associated")

            user.is_active = True

            db.commit()
            db.refresh(user)
        except HTTPException as exc:
            raise exc
        except Exception:
            db.rollback()
            raise HTTPException(500, "An error occurred on our end")

        return user

    def admin_activate_user(self, db: Session, user_id: str) -> User:
        """Activate user without requiring activation token"""

        try:
            user = self.fetch_by_id(db=db, id=user_id)

            user.is_active = True

            db.commit()
            db.refresh(user)
        except HTTPException as exc:
            raise exc
        except Exception:
            db.rollback()
            raise HTTPException(500, "An error occurred on our end")

        return user

    def change_password(
        self,
        new_password: str,
        user: User,
        db: Session,
        mode: str = "change",
        old_password: Optional[str] = None,
        current_device_fingerprint: Optional[str] = None,
    ) -> Tuple[str, str]:
        """
        Method to change the user's password.\n
        Mechanism: This process invalidates all existing refresh tokens
        ensuring only current session remain alive.

        :param new_password: str: New password
        :param user: User: User object
        :param db: Session: Database session
        :param mode: str: Mode of password change (default: "change", acceptable modes are "change" and "reset")
        :param old_password: Optional[str]: Old password (if provided)
        :return: Tuple[str, str]: New access and refresh tokens
        """

        if mode not in ["change", "reset"]:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Unable to change/reset password",
            )
        if old_password == new_password:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Old Password and New Password cannot be the same",
            )
        if old_password is None:
            if user.password is None or mode == "reset":
                user.password = self.hash_password(new_password)
                db.commit()
            else:
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    detail="Old Password must not be empty.",
                )
        elif not self.verify_password(old_password, user.password):
            raise HTTPException(status_code=400, detail="Incorrect old password")
        else:
            user.password = self.hash_password(new_password)
            db.commit()

        # Revoke all old refresh tokens
        self._batch_delete_refresh_tokens(db=db, user_id=user.id)

        # create new credentials
        new_access_token = self.create_access_token(db=db, user_obj=user)
        new_refresh_token = self.create_refresh_token(
            db=db, user_id=user.id, user_device_fingerprint=current_device_fingerprint
        )

        return (
            new_access_token,
            new_refresh_token,
        )

    def create_and_encrypt_temp_login_token(
        self, user_id: str, ip_address: str, validity: int = 10
    ) -> str:
        """
        Generate and encrypt temporary login token.\n
        Helps in tracking user login attempt source and IP.
        """
        expire = dt.datetime.now(dt.timezone.utc) + dt.timedelta(minutes=validity)
        to_encode = {
            "sub": user_id,
            "exp": expire,
            "2fa_pending": True,
            "ip": ip_address,
        }
        encoded_token = jwt.encode(
            to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM
        )

        encrypted_token = cipher_suite.encrypt(encoded_token.encode())
        encoded_encrypted_token = base64.urlsafe_b64encode(encrypted_token).decode()

        return encoded_encrypted_token

    def decrypt_and_validate_2fa_temp_login_token(
        self, token: str, current_ip: str
    ) -> str:
        """
        Decrypt and validate temporary login token. \n
        Return owner ID if valid, raise HTTPException otherwise
        """
        try:
            decoded_encrypted_token = base64.urlsafe_b64decode(token)
            payload = cipher_suite.decrypt(decoded_encrypted_token).decode()

            payload = jwt.decode(
                payload, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
            )
            if not payload.get("2fa_pending"):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN, detail="Not a 2FA token"
                )

            if payload.get("ip") != current_ip:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="IP mismatch! You're not the initiator of this login.",
                )

            return payload.get("sub", None)
        except ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Token has expired, Please restart login process.",
            )
        except JWTError as e:

            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Invalid temporary login token: {e}",
            )

        except Exception as exc:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=exc
            )

    def get_user_attributes(
        self, db: Session, user_obj: User = None, user_id: str = None
    ) -> dict:
        """Convert auth user attributes to a dictionary. expects user object or user ID"""

        if not any([user_obj, user_id]):
            raise ValueError("User ID or User Object must be given")

        attributes = None

        if user_obj:
            pass
        elif user_id:
            user_obj = self.fetch_by_id(db=db, id=user_id)

        attributes = {}
        for user_attr_record in user_obj.attributes:
            if user_attr_record.attribute and user_attr_record.attribute_value:
                attribute_name = user_attr_record.attribute.name
                attribute_value = user_attr_record.attribute_value.value
                attributes[attribute_name] = attribute_value

        if not attributes:
            return {}
        return attributes

    def add_new_attribute_to_user(
        self, db: Session, user_id: str, key: str, value: str
    ) -> UserAttribute:
        """Associate new attribute to a user"""

        key, value = key.lower(), value.lower()

        attr_exist = (
            db.query(UserAttribute)
            .filter(UserAttribute.key == key, UserAttribute.user_id == user_id)
            .first()
        )
        if attr_exist:
            raise HTTPException(
                detail=f"user already have attribute '{key}'",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        attr = UserAttribute(user_id=user_id, key=key, value=value)

        db.add(attr)
        db.commit()

        return attr

    def delete_user_attribute(self, db: Session, attribute_id: str, user_id: str):
        """Delete a user attribute"""

        try:
            db.query(UserAttribute).filter(
                UserAttribute.user_id == user_id,
                UserAttribute.attribute_id == attribute_id,
            ).delete()
            db.commit()
        except Exception as e:
            print(e)
            db.rollback()
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="error deleting attribute",
            )

    def delete_all_user_attributes(self, db: Session, user_id: str):
        """Delete all attributes associated with a user"""

        pass

    def restore_soft_deleted_user(self, db: Session, user_identifier: str) -> User:
        """
        Restore a soft deleted user account
        """

        if "@" in user_identifier:
            # If the identifier is an email, fetch user by email
            user = db.query(User).filter(User.email == user_identifier).first()
        elif "-" in user_identifier:
            # If the identifier is an ID, fetch user by ID
            user = db.query(User).filter(User.id == user_identifier).first()
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid user identifier format. Use email or ID.",
            )

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="User not found"
            )

        if not user.is_deleted:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="User is not deleted",
            )

        user.is_deleted = False
        user.is_active = True
        db.commit()
        db.refresh(user)

        return user

    def ban_user(self, db: Session, user_id: str, reason: str) -> User:
        """Ban user auth account"""

        user = self.fetch_by_id(db=db, id=user_id)
        user.is_banned = True

        # add user to ban history
        db.add(AccountBanHistory(status=BanHistoryStatusEnum.BANNED, reason=reason))
        db.commit()

        return user

    def unban_user(self, db: Session, user_id: str, reason: str) -> User:
        """Unban user auth account"""

        user = self.fetch_by_id(db=db, id=user_id)
        user.is_banned = False

        # add user ban status to history
        db.add(AccountBanHistory(status=BanHistoryStatusEnum.LIFTED, reason=reason))
        db.commit()

        return user

    def ensure_administrator(
        self, user: User, err_msg: str = None
    ) -> bool | HTTPException:
        """
        validate to ensure user is a moderator or superadmin.
        Raise HTTPexception otherwise.
        """

        if not any([user.is_superadmin, user.is_moderator]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=err_msg or "Not enough permissions.",
            )

        return True

    def ensure_superadmin(
        self, user: User, err_msg: str = None
    ) -> bool | HTTPException:
        """
        validate to ensure user is a superadmin.
        Raise HTTPexception otherwise.
        """

        if not user.is_superadmin:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=err_msg or "Not enough permissions.",
            )

        return True

    def ensure_moderator(self, user: User, err_msg: str = None) -> bool | HTTPException:
        """
        validate to ensure user is a moderator.
        Raise HTTPexception otherwise.
        """

        if not user.is_moderator:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=err_msg or "Not enough permissions.",
            )

        return True

    def upgrade_user_primary_role(
        self, db: Session, user_id: str, new_role: str, assigner_id: str
    ) -> User:
        """
        Upgrade a user's primary role.

        :param db: Database Session
        :param user_id: ID of the user to be upgraded
        :param new_role: Role to assign to user
        :param assigner_id: ID of the admin performing the upgrade
        """

        # Prevent self-role changes
        if user_id == assigner_id:
            raise HTTPException(
                detail="You cannot modify your own role.",
                status_code=status.HTTP_403_FORBIDDEN,
            )

        if new_role == PrimaryRoleEnum.USER:
            raise HTTPException(
                detail="Invalid role upgrade. Cannot upgrade to 'user' role.",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        target_user = self.fetch_by_id(db=db, id=user_id)

        if not target_user.is_moderator and not target_user.is_superadmin:
            if new_role == PrimaryRoleEnum.MODERATOR:
                target_user.is_moderator = True
            elif new_role == PrimaryRoleEnum.SUPERADMIN:
                target_user.is_superadmin = True

        elif target_user.is_moderator:
            if new_role == PrimaryRoleEnum.MODERATOR:
                raise HTTPException(
                    detail=f"User already has the '{PrimaryRoleEnum.MODERATOR}' role",
                    status_code=status.HTTP_409_CONFLICT,
                )
            elif new_role == PrimaryRoleEnum.SUPERADMIN:
                target_user.is_moderator = False
                target_user.is_superadmin = True
        else:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Cannot upgrade role further",
            )

        # save the changes
        target_user.save(db=db)

        return target_user

    def downgrade_user_primary_role(
        self, db: Session, user_id: str, new_role: str, assigner_id: str
    ) -> User:
        """
        Downgrade a user's primary role

        :param db: Database Session
        :param user_id: ID of the user to be downgraded
        :param new_role: Role to assign to user
        :param assigner_id: ID of the admin performing the downgrade
        """

        # Prevent self-role changes
        if user_id == assigner_id:
            raise HTTPException(
                detail="You cannot modify your own role.",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        if new_role == PrimaryRoleEnum.SUPERADMIN:
            raise HTTPException(
                detail="Invalid role downgrade. Cannot downgrade to 'superadmin' role.",
                status_code=status.HTTP_400_BAD_REQUEST,
            )

        target_user = self.fetch_by_id(db=db, id=user_id)

        if target_user.is_superadmin:
            # check to see if there is at least one other superadmin
            superadmin_count = (
                db.query(User)
                .filter(User.is_superadmin == True)
                .filter(User.id != user_id)
                .count()
            )
            if superadmin_count == 0:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Cannot downgrade. at least one superadmin must remain in the system.",
                )
            if new_role == PrimaryRoleEnum.MODERATOR:
                target_user.is_superadmin = False
                target_user.is_moderator = True
            elif new_role == PrimaryRoleEnum.USER:
                target_user.is_superadmin = False
        elif target_user.is_moderator:
            if new_role == PrimaryRoleEnum.USER:
                target_user.is_moderator = False
            elif new_role == PrimaryRoleEnum.MODERATOR:
                raise HTTPException(
                    detail="User already has the 'moderator' role",
                    status_code=status.HTTP_409_CONFLICT,
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Cannot downgrade role further",
            )

        target_user.save(db)

        return target_user

    def fetch_user_ban_history(
        self, db: Session, user_id: str
    ) -> list[AccountBanHistory]:
        """Fetch user account ban history"""

        history = (
            db.query(AccountBanHistory)
            .filter(AccountBanHistory.user_id == user_id)
            .order_by(AccountBanHistory.created_at.desc())
            .all()
        )

        return history

    def fetch_user_active_sessions(
        self, db: Session, user_id: str
    ) -> list[RefreshToken]:
        """Fetch user active sessions"""

        sessions = (
            db.query(RefreshToken)
            .filter(
                RefreshToken.user_id == user_id,
                RefreshToken.revoked == False,
                RefreshToken.expires_at > dt.datetime.now(dt.timezone.utc),
            )
            .order_by(RefreshToken.created_at.desc())
            .all()
        )

        return sessions

    def fetch_user_temp_tokens(
        self, db: Session, user_identifier: str
    ) -> list[TempToken]:
        """Fetch user temporary tokens"""

        tokens = (
            db.query(TempToken)
            .filter(TempToken.user_identifier == user_identifier)
            .order_by(TempToken.expires_at.desc())
            .all()
        )

        return tokens

    def fetch_temp_token(self, db: Session, token: str) -> TempToken | None:
        """Fetch a temporary token by its token string"""

        temp_token = db.query(TempToken).filter(TempToken.token == token).first()

        return temp_token

    def validate_temp_token_and_mark_as_used(self, db: Session, token: str) -> None:
        """
        Validates that a temporary token is unused. raise HTTPError if token has been previously used.
        Marks the token as used since validating means it's being used.
        """

        temp_token = self.fetch_temp_token(db=db, token=token)

        if not temp_token:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Token not found"
            )

        if temp_token.used:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Token has already been used",
            )

        # mark token as used
        temp_token.used = True
        temp_token.save(db=db)
