from api.v1.services.user import UserService
from api.v1.services.device import DevicesService
from api.v1.services.audit_log import AuditLogService
from api.v1.services.notification import Notification
from api.v1.services.totp import TOTPService
from api.v1.services.oauth2 import OAuth2Service
from api.v1.services.geoip import GeoIPService
from api.v1.services.country_blacklists import CountryBlacklistService
from api.v1.services.app_services import ApplicationService
from api.v1.services.role_service import RoleService
from api.v1.services.webhook import WebhookService
from api.v1.services.attributes import AttributeService

user_service = UserService()
devices_service = DevicesService()
audit_log_service = AuditLogService()
notification_service = Notification()
totp_service = TOTPService()
oauth2_service = OAuth2Service()
geoip_service = GeoIPService()
country_blacklist_service = CountryBlacklistService()
application_service = ApplicationService()
secondary_role_service = RoleService()
webhook_service = WebhookService()
attribute_service = AttributeService()
