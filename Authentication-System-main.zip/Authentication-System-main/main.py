"""Main App Module"""

from contextlib import asynccontextmanager
from fastapi import FastAPI, status, Request, HTTPException
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from api.v1.routes import api_version_one
from api.v1.models.mmdb import MMDB_TRACKER
from api.v1.schemas.main import ProbeServerResponse, HomeResponse
from api.core.logging.logging_config import setup_logging
from fastapi.templating import Jinja2Templates
from api.utils.json_response import JsonResponseDict
from api.utils.vault_utils import (
    rotate_service_signing_key,
    prune_old_keys,
    rotation_worker,
)
from api.utils.schedulers import scheduler
from api.utils.settings import settings
from starlette.middleware.sessions import SessionMiddleware
import asyncio


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan function"""

    # STARTUP EVENTS
    # setup application level log
    setup_logging()
    # setup and register schedulers
    if not scheduler.running:
        scheduler.start()
    # Initiate GeoIP tracker
    MMDB_TRACKER()
    # Genrate Service Apps RS256 Keypair
    current_kid = await rotate_service_signing_key(app)
    print(f"kid: {current_kid}")  # Dev debug
    # Prune services keys on startup. system will autonatically prune thereafter
    prune_old_keys()
    # Automatic service keys rotation
    app.state.service_keypair_rotation_task = asyncio.create_task(rotation_worker(app))

    yield

    # SHUTDOWN EVENTS
    # shutdown scheduler
    scheduler.shutdown(wait=False)
    # stop key rotation task
    app.state.service_keypair_rotation_task.cancel()
    try:
        await app.state.service_keypair_rotation_task
    except asyncio.CancelledError:
        # This error is expected when cancelling the task
        pass


if settings.DEBUG_MODE:
    openapi_url = "/openapi.json"
else:
    openapi_url = None


app = FastAPI(
    lifespan=lifespan,
    title="FastAPI Authentication System",
    description="Welcome to FastAPI Authentication system by [Ajiboye Pius A.](https://ajiboye-pius.vercel.app)",
    version="1.0.0",
    license_info={"name": "MIT"},
    contact={
        "name": "AuthSystem API Support",
    },
    docs_url="/documentation",
    openapi_url=openapi_url,
)

# CROSS-ORIGIN MIDDLEWARE
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

#  SESSION MIDDLEWARE
app.add_middleware(SessionMiddleware, secret_key=settings.SECRET_KEY)


email_templates = Jinja2Templates(directory="smtp/templates/html_mail_templates")


@app.get("/", include_in_schema=False, status_code=status.HTTP_307_TEMPORARY_REDIRECT)
def root(request: Request):
    return RedirectResponse(url=request.url_for("home"))


@app.get(
    "/docs", include_in_schema=False, status_code=status.HTTP_307_TEMPORARY_REDIRECT
)
def root(request: Request):
    return RedirectResponse(url=f"{str(request.base_url).strip('/')}/documentation")


@app.get(
    "/auth/system/home",
    tags=["Home"],
    status_code=status.HTTP_200_OK,
    response_model=HomeResponse,
)
async def home(request: Request):
    """
    Homepage
    """

    return {
        "message": "Welcome to FastAPI Auth System!",
        "status_code": status.HTTP_200_OK,
        "data": {
            "author": {
                "name": "Ajiboye Pius Adeleye",
                "website": "https://ajiboye-pius.vercel.app",
                "github": "https://github.com/Adeleye080",
            },
            "contributors": [],
            "URL": f"{str(request.base_url).strip('/')}/auth/system/home",
            "documentation": f"{str(request.base_url).strip('/')}/documentation",
        },
    }


@app.get(
    "/auth/system/probe",
    tags=["Home"],
    status_code=status.HTTP_200_OK,
    response_model=ProbeServerResponse,
)
async def probe_server():
    """
    Probe the server
    """
    return {
        "message": "I am the Python FastAPI API responding to probe",
        "status": "Healthy ♥️",
    }


app.include_router(api_version_one)


# REGISTER EXCEPTION HANDLERS
@app.exception_handler(HTTPException)
async def http_exception(request: Request, exc: HTTPException):
    """HTTP exception handler"""

    return JsonResponseDict(
        status_code=exc.status_code,
        message=exc.detail,
        status="error",
    )


@app.exception_handler(404)
async def not_found_exception(request: Request, exc: HTTPException):
    """HTTP exception handler"""

    return JsonResponseDict(
        status_code=exc.status_code,
        message=exc.detail or "Not Found",
        status="error",
    )


@app.exception_handler(RequestValidationError)
async def validation_exception(request: Request, exc: RequestValidationError):
    """Validation exception handler"""

    errors = [
        f'{error["msg"]}'
        + f'{". location: " + str(error["loc"]) if error["loc"] else ""}'
        for error in exc.errors()
    ]

    return JSONResponse(
        status_code=422,
        content={
            "status": "error",
            "status_code": 422,
            "message": f"Invalid input: {errors}",
        },
    )


# webhooks
@app.webhooks.post("oauth2-signup")
async def new_oauth2_signup():
    """
    When a new user signs up with the oauth2 flow, we will send you an `oauth2-signup` event POST request with this data
    to the webhook URL that you register with our system.

    **Security Requirements:**
    - If you use a firewall or IP allowlist, add this server's IP to the allowed list.
    - If your webhook endpoint is browser-based, ensure your CORS policy allows requests from this domain.
    """


@app.webhooks.post("user-hard-delete")
async def user_hard_delete():
    """
    When a user is deleted, we will send you a `user-hard-delete` event POST request with this data
    to the webhook URL that you register with our system.
    """
